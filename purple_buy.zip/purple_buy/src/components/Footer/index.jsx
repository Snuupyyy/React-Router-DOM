import { Box, Typography, Link as MuiLink } from '@mui/material'
import { Link } from 'react-router-dom'

export default function Footer(){
    return(
        <Box
            sx={{
                minWidth: '100vw',
                bgcolor: 'primary.main',
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                overflow: 'hidden',
            }}
            >
            <Typography
                sx={{
                    fontSize: '14px',
                    width: '100%',
                    margin: '30px 0px',
                    textAlign: 'center',
                    color: 'quintanary.main',
                }}
                variant='subtitle1'
                > 
                    Site criado por Daniel Henrique
            </Typography>

                 
            <Typography
                sx={{
                    fontSize: '14px',
                    width: '100%',
                    margin: '30px 0px',
                    textAlign: 'center',
                    color: 'quintanary.main',
                }}
                variant='subtitle1'
                >
                Entre em contato com Outras
                <Link to="/purple_buy/contact">
                    <Typography
                        sx={{
                            fontSize: '14px',
                            display: 'inline-block',
                            color: 'quaternary.main',
                            bgcolor: 'secondary.main',
                            padding: '6px',
                            margin: '6px',
                            textDecoration: 'none',
                            '&:hover':{
                                color: 'quaternary.main',
                            }
                        }}
                    >   
                        Formas de Contato
                    </Typography>
                </Link>

            </Typography>
        
        </Box>
    )
}