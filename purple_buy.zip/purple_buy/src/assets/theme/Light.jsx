import { createTheme } from "@mui/material/styles"

export const LightTheme = createTheme({
    palette:{
        primary:{
            main: '#4287f5',
        },
        secondary:{
            main: '#0303fc',
        },
        terciary:{
            main: '#4287f5',
        },
        quaternary:{
            main: '#f2f2f2',
        },
        quintanary:{
            main: '#0d0d0d'
        },
        background:{
        default: '#f2f2f2',
        }
    }
})